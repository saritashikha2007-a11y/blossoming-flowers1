
onload = () => {
  const c = setTimeout(() => {
    document.body.classList.remove("not-loaded");
    clearTimeout(c);
  }, 1000);
};

function openOverlay() {
  document.getElementById("overlay").classList.add("show");
  document.querySelector(".open-button-container").style.display = "none";
}

function closeOverlay() {
  document.getElementById("overlay").classList.remove("show");
  document.querySelector(".open-button-container").style.display = "flex";
}
